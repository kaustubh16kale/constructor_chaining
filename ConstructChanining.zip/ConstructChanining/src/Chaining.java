class vehicle{
	String make;
	String model;
	int year;
	String color;
	vehicle(){
		make="";
		model="";
		year=0;
		color="";	}
	vehicle(String make,String model,int year,String color){
		this.make=make;
		this.model=model;
		this.year=year;
		this.color=color;
		
	}
	vehicle(String make,String model,int year){
		this.make=make;
		this.model=model;
		this.year=year;
		this.color="unknown";
	}
}
class car extends vehicle{
	int numDoors;
	boolean automatic;
	car(){
		super();
		this.numDoors=0;
		this.automatic=false;
		}
	car(String make,String model,int year,String color,int numDoors,boolean automatic){
		super(make,model,year,color);
		this.numDoors=numDoors;
		this.automatic=automatic;	
		}
	car(String make,String model,int year){
		super(make,model,year);
		this.numDoors=0;
		this.automatic=false;
	}
}
class truck extends vehicle{
	double payload;
	double towing;
	truck(){
		super();
		this.payload=0;
		this.towing=0;
	}
	truck(String make,String model,int year,String color,double payload,double towing){
		super(make, model, year, color);
		this.payload=payload;
		this.towing=towing;
	}
	truck(String make,String model,int year){
		super(make, model, year);
		this.payload=0;
		this.towing=0;
	}
	
}
public class Chaining {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
